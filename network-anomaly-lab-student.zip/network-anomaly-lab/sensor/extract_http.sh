#!/usr/bin/env bash
# Извлечение HTTP-полей из PCAP в CSV через tshark.
#
# Использование:
#   bash /sensor/extract_http.sh                    # дефолтные пути
#   bash /sensor/extract_http.sh /reports/x.pcap /reports/x.csv

set -euo pipefail

IN="${1:-${SENSOR_PCAP:-/reports/lab_capture.pcap}}"
OUT="${2:-${SENSOR_CSV:-/reports/http_flows.csv}}"

if [[ ! -s "$IN" ]]; then
    echo "[extract] PCAP $IN отсутствует или пустой" >&2
    exit 2
fi

echo "[extract] $IN -> $OUT"

# Заголовок CSV в одну строку.
printf 'frame.time_epoch,ip.src,ip.dst,tcp.srcport,tcp.dstport,http.request.method,http.host,http.request.uri,http.user_agent,http.response.code,http.content_length\n' > "$OUT"

# tshark: разворачиваем все http-фреймы. -E separator=, делает CSV.
# Заголовок мы пишем сами выше, поэтому header=n.
tshark -r "$IN" \
       -Y 'http.request or http.response' \
       -T fields \
       -e frame.time_epoch \
       -e ip.src -e ip.dst \
       -e tcp.srcport -e tcp.dstport \
       -e http.request.method \
       -e http.host \
       -e http.request.uri \
       -e http.user_agent \
       -e http.response.code \
       -e http.content_length \
       -E separator=, -E quote=d -E header=n \
       >> "$OUT"

LINES=$(wc -l < "$OUT")
echo "[extract] CSV строк: $LINES"
