#!/usr/bin/env bash
# Захват HTTP-трафика на учебном Docker-мосту.
#
# Использование (внутри контейнера sensor):
#   bash /sensor/capture.sh [duration_seconds]
# Из хоста:
#   docker compose exec sensor bash /sensor/capture.sh 60
#
# Результат: $SENSOR_PCAP (по умолчанию /reports/lab_capture.pcap).

set -euo pipefail

DURATION="${1:-60}"
IFACE="${SENSOR_IFACE:-eth0}"
OUT="${SENSOR_PCAP:-/reports/lab_capture.pcap}"

mkdir -p "$(dirname "$OUT")"

echo "[capture] iface=$IFACE duration=${DURATION}s out=$OUT"

# -U: writes packets without buffering (важно: иначе при прерывании PCAP может оказаться пустым).
# -G длительность ротации, -W 1 один файл, -i интерфейс,
# фильтр: только TCP/80 (HTTP открытым текстом — этого хватает для лабы).
tcpdump -i "$IFACE" -nn -s 0 -U -w "$OUT" -G "$DURATION" -W 1 \
        'tcp port 80' \
        2> >(grep -v 'packets captured' >&2) &
PID=$!

# Если tcpdump уйдёт в ошибку, не зависаем.
trap 'kill $PID 2>/dev/null || true' INT TERM EXIT

# Ждём истечения окна.
wait "$PID" || true

echo "[capture] done -> $OUT"
ls -lh "$OUT" || true
