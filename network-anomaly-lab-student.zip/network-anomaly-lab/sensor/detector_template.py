#!/usr/bin/env python3
"""Шаблон детектора аномалий (СТУДЕНЧЕСКИЙ файл).

Задача: дописать недостающие проверки в функциях detect_*(...) и сохранить
итог в /reports/detections_student.json.

Что уже сделано за вас:
    * чтение CSV, экспортированного из PCAP через extract_http.sh;
    * приведение типов (frame.time_epoch -> float, http.response.code -> int);
    * скелет правил для пяти типов аномалий;
    * запись результата.

Что нужно сделать вам:
    1. В каждой функции detect_*() добавить логику и заполнить items.
    2. В main() при необходимости отрегулировать пороги.
    3. Сравнить итог с эталоном преподавателя и описать находки в отчёте.

Подсказки:
    * Подозрительные UA: 'curl', 'python-requests', '', 'sqlmap' — но какие именно
      встречаются в вашем CSV?
    * Traversal — ищите в http.request.uri токены '..', '%2e', '%2f', 'etc/passwd'.
    * SQLi-like — символы '\\'', 'UNION', 'OR 1=1', '--', ';' в URI или query.
    * HTTP flood — кратное превышение средней частоты запросов с одного IP.
    * Large upload — http.content_length > N в POST-запросах.
    * Credential stuffing — серия POST /api/auth/login с разными username и
      высокой долей 401.

Не подсматривайте в /reports/ground_truth.json — это файл преподавателя.
"""

from __future__ import annotations

import csv
import json
import os
import re
import statistics
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Iterable, List, Optional


CSV_DEFAULT = "/reports/http_flows.csv"
OUT_DEFAULT = "/reports/detections_student.json"


@dataclass
class Finding:
    type: str
    severity: str  # low / medium / high
    description: str
    samples: List[Dict[str, Any]] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Чтение CSV
# --------------------------------------------------------------------------- #

def load_rows(path: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with open(path, newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for raw in reader:
            try:
                row = {
                    "ts": float(raw["frame.time_epoch"]) if raw.get("frame.time_epoch") else 0.0,
                    "ip_src": raw.get("ip.src", "") or "",
                    "ip_dst": raw.get("ip.dst", "") or "",
                    "sport": raw.get("tcp.srcport", "") or "",
                    "dport": raw.get("tcp.dstport", "") or "",
                    "method": raw.get("http.request.method", "") or "",
                    "host": raw.get("http.host", "") or "",
                    "uri": raw.get("http.request.uri", "") or "",
                    "ua": raw.get("http.user_agent", "") or "",
                    "code": int(raw["http.response.code"]) if raw.get("http.response.code") else 0,
                    "clen": int(raw["http.content_length"]) if raw.get("http.content_length") else 0,
                }
            except ValueError:
                continue
            rows.append(row)
    return rows


# --------------------------------------------------------------------------- #
# Детекторы (заглушки — дополните их)
# --------------------------------------------------------------------------- #

def detect_suspicious_user_agents(rows: Iterable[Dict[str, Any]]) -> Optional[Finding]:
    """Найдите запросы с подозрительными User-Agent."""
    # TODO студент: соберите items с примерами {ts, ip_src, uri, ua}.
    items: List[Dict[str, Any]] = []
    for r in rows:
        if not r["method"]:
            continue
        # пример заготовки — раскомментируйте и дополните:
        # ua_l = r["ua"].lower()
        # if ua_l.startswith("curl/") or "python-requests" in ua_l or ua_l == "" or "sqlmap" in ua_l:
        #     items.append({"ts": r["ts"], "ip_src": r["ip_src"], "uri": r["uri"], "ua": r["ua"]})
        pass
    if not items:
        return None
    return Finding(type="suspicious_user_agent", severity="low",
                   description="запросы с известными подозрительными UA",
                   samples=items[:10])


def detect_directory_traversal(rows: Iterable[Dict[str, Any]]) -> Optional[Finding]:
    """Найдите traversal-payload в URI."""
    items: List[Dict[str, Any]] = []
    # TODO студент: проверяйте URI на '..', '%2e', '%2f', 'etc/passwd' и т.п.
    return Finding(type="directory_traversal", severity="medium",
                   description="попытки path traversal в URI",
                   samples=items[:10]) if items else None


def detect_sqli_probes(rows: Iterable[Dict[str, Any]]) -> Optional[Finding]:
    """Найдите SQL-like payload в URI или query."""
    items: List[Dict[str, Any]] = []
    # TODO студент: символы кавычек, UNION, OR 1=1, ';', '--'
    return Finding(type="sql_injection_probes", severity="medium",
                   description="SQLi-подобные payload в запросах",
                   samples=items[:10]) if items else None


def detect_credential_stuffing(rows: Iterable[Dict[str, Any]]) -> Optional[Finding]:
    """Серия POST /api/auth/login с разных username и большим числом 401."""
    items: List[Dict[str, Any]] = []
    # TODO студент: посчитайте, сколько POST /api/auth/login пришло с одного IP
    # за короткий промежуток и какая доля закончилась 401.
    return Finding(type="credential_stuffing", severity="high",
                   description="много неуспешных логинов с одного IP",
                   samples=items[:10]) if items else None


def detect_large_upload(rows: Iterable[Dict[str, Any]]) -> Optional[Finding]:
    """POST с http.content_length, явно превышающим обычные значения."""
    items: List[Dict[str, Any]] = []
    # TODO студент: подберите порог (хинт: 1MB+) и соберите примеры.
    return Finding(type="large_upload", severity="medium",
                   description="POST с аномально большим телом",
                   samples=items[:10]) if items else None


def detect_http_flood(rows: List[Dict[str, Any]]) -> Optional[Finding]:
    """Резкий всплеск RPS с одного источника."""
    items: List[Dict[str, Any]] = []
    # TODO студент: сгруппируйте запросы по ip_src в окнах ~1с,
    # сравните с медианой по другим окнам.
    return Finding(type="http_flood", severity="high",
                   description="всплеск частоты запросов с одного IP",
                   samples=items[:10]) if items else None


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #

def main(argv: Optional[List[str]] = None) -> int:
    argv = argv or sys.argv[1:]
    csv_path = argv[0] if argv else CSV_DEFAULT
    out_path = argv[1] if len(argv) > 1 else OUT_DEFAULT

    if not os.path.exists(csv_path):
        print(f"[detector] no CSV at {csv_path}", file=sys.stderr)
        return 2

    rows = load_rows(csv_path)
    print(f"[detector] loaded {len(rows)} rows")

    findings: List[Finding] = []
    for fn in (
        detect_suspicious_user_agents,
        detect_directory_traversal,
        detect_sqli_probes,
        detect_credential_stuffing,
        detect_large_upload,
        detect_http_flood,
    ):
        f = fn(rows)
        if f is not None:
            findings.append(f)

    report = {
        "schema": "network-anomaly-lab/detections/student/v1",
        "csv": csv_path,
        "rows": len(rows),
        "findings": [asdict(f) for f in findings],
    }
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"[detector] {len(findings)} типов аномалий → {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
