#!/usr/bin/env bash
# Установка Docker Engine + Compose plugin на чистый Ubuntu 22.04/24.04
# и запуск стенда из текущей директории. Скрипт идемпотентен.
set -euo pipefail

if [[ "$(id -u)" -eq 0 ]]; then
    SUDO=""
else
    SUDO="sudo"
fi

echo "[deploy] обновление apt-репозиториев"
$SUDO apt-get update -y

echo "[deploy] установка зависимостей"
$SUDO apt-get install -y ca-certificates curl gnupg make

if ! command -v docker >/dev/null 2>&1; then
    echo "[deploy] установка Docker Engine"
    $SUDO install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
        | $SUDO gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    $SUDO chmod a+r /etc/apt/keyrings/docker.gpg
    . /etc/os-release
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" \
        | $SUDO tee /etc/apt/sources.list.d/docker.list >/dev/null
    $SUDO apt-get update -y
    $SUDO apt-get install -y docker-ce docker-ce-cli containerd.io \
        docker-buildx-plugin docker-compose-plugin
fi

if ! groups "$USER" | tr ' ' '\n' | grep -qx docker; then
    echo "[deploy] добавляю $USER в группу docker (потребуется перелогин)"
    $SUDO usermod -aG docker "$USER" || true
fi

cd "$(dirname "$0")/../.."
if [[ ! -f .env ]]; then
    cp .env.example .env
    echo "[deploy] создан .env из .env.example"
fi

echo "[deploy] make up"
make up

echo "[deploy] готово. Сервис доступен на http://127.0.0.1:${NGINX_HOST_PORT:-8080}"
