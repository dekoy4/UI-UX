"""Профили нетипичных HTTP-клиентов для генератора аномального трафика.

Эмулирует запросы от desktop-приложений (офисные и инженерные пакеты),
которые иногда встречаются в логах корпоративных веб-серверов: некоторые
из них тянут updates, телеметрию или sync-токены через HTTP. В рамках
учебного стенда это служит «разнообразным фоном» аномального сценария
и помогает студенту увидеть, насколько широким бывает множество User-Agent.
"""

from __future__ import annotations

import random
from typing import List


# Набор «легаси» User-Agent. Список фиксированный, потому что в учебной
# лабе нам важна воспроизводимость: при том же seed одни и те же UA.
_LEGACY_OFFICE_UA: List[str] = [
    "Microsoft-Office/16.0 (Windows NT 10.0; Microsoft Outlook 16.0.14931; Pro)",
    "Adobe-Acrobat/2023.006.20380 (Windows; rv:2023.6) like Mozilla",
    "OneDrive/23.171.0820.0001 (Windows NT 10.0.19045) MicrosoftSync/1.0",
    "SharePoint Designer/16.0.5404.1000 (compatible; MS-Office)",
    "AutoCAD/24.2.51.0 (Win64; AcWebBrowser/2.0)",
    "MATLAB/9.14.0.2206163 (R2023a) JavaPlatformBrowser/11",
    "LabVIEW/22.3 (Windows; NI-VISA 21.5) HttpClient/1.0",
    "SolidWorks/2024 SP2.0 (Windows NT 10.0; eDrawings 32.0)",
    "Photoshop/25.5.0 (Windows; AdobeCreativeCloudLibrary/4.0)",
    "QuickBooks/Online 24.0 (Intuit-QBO; SyncEngine 7)",
    "Salesforce-CRM-Connector/52.0 (sf-sdk/8.1; com.salesforce.api)",
    "Wolfram-Mathematica/13.3 (NumberCrunch/4.0; Win64)",
]


# Несколько «прикладных» URI, по которым такие клиенты обычно обращаются.
_LEGACY_PATHS: List[str] = [
    "/api/files?name=quarterly-report.xlsx",
    "/api/files?name=invoice.docx",
    "/api/files?name=architecture.dwg",
    "/api/search?q=Excel+macro+CVE-2023",
    "/api/search?q=AutoCAD+drawing+meta",
    "/api/search?q=SharePoint+sync+token",
]


def pick_ua(rng: random.Random) -> str:
    """Выбрать User-Agent одного из «легаси» клиентов."""
    return rng.choice(_LEGACY_OFFICE_UA)


def pick_path(rng: random.Random) -> str:
    """Выбрать характерный URI для этих клиентов."""
    return rng.choice(_LEGACY_PATHS)


def all_uas() -> List[str]:
    """Полный список UA — нужен, когда хотим воспроизводимый полный обход."""
    return list(_LEGACY_OFFICE_UA)


def all_paths() -> List[str]:
    return list(_LEGACY_PATHS)
