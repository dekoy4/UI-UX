#!/usr/bin/env python3
"""network-anomaly-lab — генератор учебного трафика.

Возможности:
  * нормальный сценарий: register → login → products → search → profile → upload;
  * аномальный сценарий: credential stuffing, traversal-probes, SQL-like probes,
    HTTP flood (ограниченная скорость), large POST, подозрительные User-Agent.

Безопасность:
  * по умолчанию целевой URL — http://nginx:80 (то есть только локальная
    Docker-сеть). Внешние домены запрещены — это учебный стенд, не инструмент.
  * длительность ограничена сверху, частота flood'а лимитирована.

Файл ground_truth.json пишется в /reports и содержит timeline
сгенерированных событий — нужен для отладки самих сценариев генератора.
"""

from __future__ import annotations

import argparse
import json
import os
import random
import string
import sys
import time
from dataclasses import dataclass, asdict, field
from ipaddress import ip_address, ip_network
from typing import Iterable, List, Optional
from urllib.parse import urlparse, urlunparse

import httpx

# Профили нетипичных desktop-клиентов (office / engineering apps),
# используются для дополнительного разнообразия аномального фона.
try:
    from client_profiles import (
        pick_ua as _cp_pick_ua,
        pick_path as _cp_pick_path,
        all_uas as _cp_all_uas,
        all_paths as _cp_all_paths,
    )
    _CLIENT_PROFILES_AVAILABLE = True
except Exception:
    _CLIENT_PROFILES_AVAILABLE = False

# -----------------------------------------------------------------------------
# Безопасность таргета
# -----------------------------------------------------------------------------

# Разрешённые хосты по имени.
_ALLOWED_HOSTS = {"nginx", "lab_nginx", "localhost", "127.0.0.1", "::1"}
# Разрешённая Docker-подсеть.
_ALLOWED_NETS = [ip_network("172.16.0.0/12"), ip_network("10.0.0.0/8"), ip_network("192.168.0.0/16")]
# Жёсткий потолок длительности и частоты, чтобы стенд не превращался в DoS.
_MAX_DURATION = 600
_FLOOD_MAX_RPS = 20  # сверху, конкретное значение выбирает сценарий


def _ensure_safe_target(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        sys.exit(f"[refused] unsupported scheme: {parsed.scheme}")
    host = parsed.hostname or ""
    if host in _ALLOWED_HOSTS:
        return url
    try:
        ip = ip_address(host)
    except ValueError:
        sys.exit(
            f"[refused] target host '{host}' is not allowed. "
            "Use nginx, localhost, 127.0.0.1 or a private Docker subnet."
        )
    for net in _ALLOWED_NETS:
        if ip in net:
            return url
    sys.exit(f"[refused] target IP {ip} is not in allowed private nets")


# -----------------------------------------------------------------------------
# Утилиты
# -----------------------------------------------------------------------------

NORMAL_USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/124.0",
]
SUSPICIOUS_USER_AGENTS = [
    "curl/8.4.0",
    "python-requests/2.31.0",
    "",  # пустой UA
    "sqlmap/1.7.11#stable (https://sqlmap.org)",  # учебно
]

PRODUCT_QUERIES = ["notebook", "mouse", "keyboard", "monitor", "router", "headphones", "hub", "webcam"]

TRAVERSAL_PROBES = [
    "/../../../../etc/passwd",
    "/..%2f..%2fetc/passwd",
    "/%2e%2e/%2e%2e/etc/shadow",
    "/static/../../etc/hosts",
]

SQLI_PROBES = [
    "' OR 1=1 --",
    "\" OR \"a\"=\"a",
    "1; DROP TABLE users",
    "UNION SELECT username, password FROM users",
    "admin'--",
]


def _rand_string(n: int = 6) -> str:
    return "".join(random.choices(string.ascii_lowercase, k=n))


def _rand_username() -> str:
    return f"user_{_rand_string(5)}"


@dataclass
class AnomalyEvent:
    """Запись в отладочный ground_truth.json."""
    type: str
    started_at: float
    ended_at: float
    target: str
    description: str
    samples: List[str] = field(default_factory=list)


# -----------------------------------------------------------------------------
# Нормальные сценарии
# -----------------------------------------------------------------------------

def normal_session(client: httpx.Client, target: str) -> None:
    """Имитирует одного «настоящего» пользователя."""
    ua = random.choice(NORMAL_USER_AGENTS)
    headers = {"User-Agent": ua}
    u = _rand_username()
    p = _rand_string(8)

    # register
    client.post(f"{target}/api/auth/register", json={"username": u, "password": p}, headers=headers)
    # login
    r = client.post(f"{target}/api/auth/login", json={"username": u, "password": p}, headers=headers)
    token = None
    try:
        token = r.json().get("token")
    except Exception:
        token = None
    auth_h = dict(headers)
    if token:
        auth_h["Authorization"] = f"Bearer {token}"

    # browse products
    client.get(f"{target}/api/products", headers=headers)
    # просмотр конкретного товара
    client.get(f"{target}/api/products/{random.randint(1, 10)}", headers=headers)
    # search
    client.get(f"{target}/api/search", params={"q": random.choice(PRODUCT_QUERIES)}, headers=headers)
    # profile
    client.get(f"{target}/api/profile", headers=auth_h)
    # upload небольшого файла
    payload = (_rand_string(64) * 8).encode()
    files = {"file": (f"{_rand_string(4)}.txt", payload, "text/plain")}
    client.post(f"{target}/api/upload", files=files, headers=headers)
    # admin stats — это нормально, dashboard опрашивает
    client.get(f"{target}/api/admin/stats", headers=headers)


def run_normal(client: httpx.Client, target: str, duration: int) -> None:
    """Гонит «нормальный фон» в течение duration секунд."""
    print(f"[normal] running for {duration}s against {target}")
    end_at = time.time() + duration
    while time.time() < end_at:
        try:
            normal_session(client, target)
        except httpx.RequestError as e:
            print(f"[normal] transient error: {e!r}")
        # пауза между сессиями 0.3-1.2с — похоже на пользователей
        time.sleep(random.uniform(0.3, 1.2))


# -----------------------------------------------------------------------------
# Аномальные сценарии
# -----------------------------------------------------------------------------

def anomaly_credential_stuffing(client: httpx.Client, target: str) -> AnomalyEvent:
    """Серия неудачных логинов под разными именами, как при credential stuffing."""
    started = time.time()
    ua = "python-requests/2.31.0"
    samples: List[str] = []
    user_list = [f"victim_{i}" for i in range(20)]
    pass_list = ["123456", "password", "qwerty", "letmein", "admin", "12345678"]
    count = 0
    for u in user_list:
        for p in pass_list:
            try:
                r = client.post(
                    f"{target}/api/auth/login",
                    json={"username": u, "password": p},
                    headers={"User-Agent": ua},
                )
                samples.append(f"login {u}/{p} -> {r.status_code}")
                count += 1
            except httpx.RequestError:
                pass
            time.sleep(0.02)
    return AnomalyEvent(
        type="credential_stuffing",
        started_at=started,
        ended_at=time.time(),
        target=target,
        description=f"{count} попыток логина с UA={ua}",
        samples=samples[:5],
    )


def anomaly_directory_traversal(client: httpx.Client, target: str) -> AnomalyEvent:
    """Зонды traversal по /api/files."""
    started = time.time()
    samples: List[str] = []
    ua = "curl/8.4.0"
    for probe in TRAVERSAL_PROBES:
        try:
            r = client.get(f"{target}/api/files", params={"name": probe}, headers={"User-Agent": ua})
            samples.append(f"name={probe} -> {r.status_code}")
        except httpx.RequestError:
            pass
        time.sleep(0.05)
    return AnomalyEvent(
        type="directory_traversal",
        started_at=started,
        ended_at=time.time(),
        target=target,
        description="набор traversal-payload по /api/files",
        samples=samples,
    )


def anomaly_sqli_probes(client: httpx.Client, target: str) -> AnomalyEvent:
    """SQLi-подобные зонды через /api/search."""
    started = time.time()
    samples: List[str] = []
    ua = "sqlmap/1.7.11#stable (https://sqlmap.org)"
    for probe in SQLI_PROBES:
        try:
            r = client.get(f"{target}/api/search", params={"q": probe}, headers={"User-Agent": ua})
            samples.append(f"q={probe!r} -> {r.status_code}")
        except httpx.RequestError:
            pass
        time.sleep(0.05)
    return AnomalyEvent(
        type="sql_injection_probes",
        started_at=started,
        ended_at=time.time(),
        target=target,
        description="SQL-like payload в q",
        samples=samples,
    )


def anomaly_http_flood(client: httpx.Client, target: str, duration: int) -> AnomalyEvent:
    """Лёгкий flood: ограниченная частота, только в Docker-сети."""
    started = time.time()
    # Жёстко ограничиваем — это учебное, а не DoS.
    rps = min(_FLOOD_MAX_RPS, 15)
    interval = 1.0 / rps
    samples: List[str] = []
    end_at = time.time() + max(3, min(duration, 20))  # не дольше 20с
    n = 0
    while time.time() < end_at:
        try:
            client.get(f"{target}/api/products", headers={"User-Agent": "python-requests/2.31.0"})
            n += 1
        except httpx.RequestError:
            pass
        time.sleep(interval)
    samples.append(f"sent {n} requests at ~{rps} rps")
    return AnomalyEvent(
        type="http_flood",
        started_at=started,
        ended_at=time.time(),
        target=target,
        description=f"учебный flood ~{rps} rps на /api/products",
        samples=samples,
    )


def anomaly_large_upload(client: httpx.Client, target: str) -> AnomalyEvent:
    """Имитация exfiltration: POST с непропорционально большим телом.

    Размер ~200 КБ выбран специально — фоновые upload'ы порядка ~500 Б,
    а tshark гарантированно reassemble'нет это в один http.request с
    полем content_length.
    """
    started = time.time()
    blob = os.urandom(200 * 1024)
    files = {"file": ("exfil.bin", blob, "application/octet-stream")}
    code = None
    try:
        r = client.post(
            f"{target}/api/upload",
            files=files,
            headers={"User-Agent": ""},  # пустой UA — ещё один признак
        )
        code = r.status_code
    except httpx.RequestError as e:
        code = f"err:{e!r}"
    return AnomalyEvent(
        type="large_upload",
        started_at=started,
        ended_at=time.time(),
        target=target,
        description=f"upload ~200KB, UA пустой, ответ {code}",
        samples=[f"size=200KB", f"status={code}"],
    )


def anomaly_suspicious_ua(client: httpx.Client, target: str) -> AnomalyEvent:
    """Прогон по обычным эндпоинтам с подозрительными UA."""
    started = time.time()
    samples: List[str] = []
    for ua in SUSPICIOUS_USER_AGENTS:
        try:
            r = client.get(f"{target}/api/products", headers={"User-Agent": ua})
            samples.append(f"ua={ua!r} -> {r.status_code}")
        except httpx.RequestError:
            pass
        time.sleep(0.05)
    return AnomalyEvent(
        type="suspicious_user_agent",
        started_at=started,
        ended_at=time.time(),
        target=target,
        description="запросы с подозрительными UA",
        samples=samples,
    )


def anomaly_legacy_clients(client: httpx.Client, target: str) -> AnomalyEvent:
    """Имитация запросов от «нетипичных» desktop-клиентов (office/eng-пакеты).

    Такие клиенты редко обращаются к публичным API и обычно бросаются
    в глаза в логах из-за специфических User-Agent.
    """
    started = time.time()
    samples: List[str] = []
    if not _CLIENT_PROFILES_AVAILABLE:
        return AnomalyEvent(
            type="suspicious_user_agent",
            started_at=started,
            ended_at=time.time(),
            target=target,
            description="client_profiles module недоступен",
            samples=[],
        )
    # Проходим по всему списку UA — гарантирует, что КАЖДЫЙ из них
    # окажется в логе/PCAP вне зависимости от seed.
    uas = _cp_all_uas()
    paths = _cp_all_paths()
    for i, ua in enumerate(uas):
        path = paths[i % len(paths)]
        try:
            r = client.get(f"{target}{path}", headers={"User-Agent": ua})
            samples.append(f"{path} ua={ua[:30]}... -> {r.status_code}")
        except httpx.RequestError:
            pass
        time.sleep(0.05)
    return AnomalyEvent(
        type="suspicious_user_agent",
        started_at=started,
        ended_at=time.time(),
        target=target,
        description="запросы от legacy desktop-клиентов",
        samples=samples[:6],
    )


def run_anomalies(client: httpx.Client, target: str, duration: int) -> List[AnomalyEvent]:
    """Запускает набор аномалий, перемежая короткими паузами."""
    print(f"[anomalies] running mix against {target}")
    events: List[AnomalyEvent] = []
    plan = [
        anomaly_suspicious_ua,
        anomaly_directory_traversal,
        anomaly_sqli_probes,
        anomaly_credential_stuffing,
        anomaly_large_upload,
        anomaly_legacy_clients,
    ]
    for fn in plan:
        events.append(fn(client, target))
        time.sleep(0.5)
    # Flood — отдельно, длительность ограничена.
    events.append(anomaly_http_flood(client, target, duration))
    return events


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------

def main(argv: Optional[Iterable[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="network-anomaly-lab traffic generator")
    parser.add_argument("--normal", action="store_true", help="генерировать нормальный трафик")
    parser.add_argument("--anomalies", action="store_true", help="генерировать аномальный трафик")
    parser.add_argument("--duration", type=int, default=int(os.environ.get("TRAFFIC_DURATION", 60)),
                        help="длительность нормального трафика (сек)")
    parser.add_argument("--seed", type=int, default=int(os.environ.get("TRAFFIC_SEED", 1337)))
    parser.add_argument("--target", default=os.environ.get("TRAFFIC_TARGET", "http://nginx:80"))
    parser.add_argument("--ground-truth", default="/reports/ground_truth.json",
                        help="путь к отладочному дампу сценария (timeline событий)")
    args = parser.parse_args(argv)

    if not args.normal and not args.anomalies:
        parser.error("укажите хотя бы один из --normal / --anomalies")

    if args.duration <= 0 or args.duration > _MAX_DURATION:
        parser.error(f"--duration должен быть в (0, {_MAX_DURATION}]")

    random.seed(args.seed)
    target = _ensure_safe_target(args.target).rstrip("/")
    print(f"[gen] target={target} seed={args.seed} duration={args.duration}")

    started_at = time.time()
    events: List[AnomalyEvent] = []
    with httpx.Client(timeout=10.0, follow_redirects=False) as client:
        if args.normal:
            run_normal(client, target, args.duration)
        if args.anomalies:
            events.extend(run_anomalies(client, target, args.duration))
    ended_at = time.time()

    # Дамп timeline для отладки.
    gt = {
        "schema": "network-anomaly-lab/ground_truth/v1",
        "target": target,
        "seed": args.seed,
        "started_at": started_at,
        "ended_at": ended_at,
        "events": [asdict(e) for e in events],
        "note": "debug timeline of generated events",
    }
    try:
        os.makedirs(os.path.dirname(args.ground_truth), exist_ok=True)
        with open(args.ground_truth, "w", encoding="utf-8") as f:
            json.dump(gt, f, indent=2, ensure_ascii=False)
        print(f"[gen] ground truth saved: {args.ground_truth}")
    except OSError as e:
        print(f"[gen] failed to write ground truth: {e!r}", file=sys.stderr)

    print(f"[gen] done. events={len(events)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
