import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite сборка для статики, которая отдаётся через Nginx.
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
  server: { host: true, port: 5173 },
});
