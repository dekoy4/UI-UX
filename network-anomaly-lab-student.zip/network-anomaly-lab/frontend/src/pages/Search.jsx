import React, { useState } from 'react';
import { api } from '../api.js';

export default function Search() {
  const [q, setQ] = useState('');
  const [items, setItems] = useState([]);
  const [err, setErr] = useState(null);

  async function go(e) {
    e.preventDefault();
    setErr(null);
    try { setItems(await api.search(q)); }
    catch (e) { setItems([]); setErr(e.message); }
  }
  return (
    <>
      <h1>Search</h1>
      <form onSubmit={go} className="card row">
        <input style={{flex:1}} placeholder="search products..." value={q} onChange={e=>setQ(e.target.value)} />
        <button type="submit">Find</button>
      </form>
      {err && <p className="err">{err}</p>}
      <div className="grid">
        {items.map(p => (
          <div className="card" key={p.id}>
            <h3 style={{marginTop:0}}>{p.name}</h3>
            <p className="muted">{p.category}</p>
            <p>${p.price.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </>
  );
}
