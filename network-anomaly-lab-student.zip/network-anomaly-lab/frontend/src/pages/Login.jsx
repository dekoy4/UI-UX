import React, { useState } from 'react';
import { api, setToken } from '../api.js';

export default function Login() {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [msg, setMsg] = useState(null);
  const [err, setErr] = useState(null);

  async function doLogin(e) {
    e.preventDefault();
    setMsg(null); setErr(null);
    try {
      const r = await api.login(u, p);
      setToken(r.token);
      setMsg(`Logged in as ${u} (${r.role}).`);
    } catch (e) { setErr(e.message); }
  }
  async function doRegister() {
    setMsg(null); setErr(null);
    try {
      const r = await api.register(u, p);
      setToken(r.token);
      setMsg(`Registered & logged in as ${u}.`);
    } catch (e) { setErr(e.message); }
  }

  return (
    <>
      <h1>Login / Register</h1>
      <form onSubmit={doLogin} className="card">
        <div className="row"><label>Username</label><input value={u} onChange={e=>setU(e.target.value)} /></div>
        <div className="row" style={{marginTop:8}}><label>Password</label><input type="password" value={p} onChange={e=>setP(e.target.value)} /></div>
        <div className="row" style={{marginTop:12, gap:8}}>
          <button type="submit">Login</button>
          <button type="button" onClick={doRegister}>Register</button>
        </div>
        {msg && <p className="ok">{msg}</p>}
        {err && <p className="err">{err}</p>}
      </form>
      <p className="muted">Демо-аккаунт можно создать прямо здесь.</p>
    </>
  );
}
