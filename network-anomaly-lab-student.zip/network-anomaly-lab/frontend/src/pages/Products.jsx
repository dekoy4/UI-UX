import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Products() {
  const [items, setItems] = useState([]);
  const [err, setErr] = useState(null);
  useEffect(() => { api.products().then(setItems).catch(e=>setErr(e.message)); }, []);
  return (
    <>
      <h1>Products</h1>
      {err && <p className="err">{err}</p>}
      <div className="grid">
        {items.map(p => (
          <div className="card" key={p.id}>
            <h3 style={{marginTop:0}}>{p.name}</h3>
            <p className="muted">{p.category}</p>
            <p>{p.description}</p>
            <p><strong>${p.price.toFixed(2)}</strong></p>
          </div>
        ))}
      </div>
    </>
  );
}
