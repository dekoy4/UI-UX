import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

// Dashboard НЕ раскрывает список аномалий — только агрегаты.
// Студенты должны сами понять, что необычные пики 4xx/5xx, странные UA
// и редкие пути в top_endpoints — это симптомы аномалий.
export default function Dashboard() {
  const [s, setS] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => {
    const tick = () => api.stats().then(setS).catch(e=>setErr(e.message));
    tick();
    const id = setInterval(tick, 3000);
    return () => clearInterval(id);
  }, []);
  if (err) return <p className="err">{err}</p>;
  if (!s) return <p className="muted">loading…</p>;
  return (
    <>
      <h1>Traffic Dashboard</h1>
      <div className="stat">
        <div className="item"><div className="muted">Total requests</div><div className="v">{s.total_requests}</div></div>
        <div className="item"><div className="muted">2xx</div><div className="v ok">{s.buckets['2xx']}</div></div>
        <div className="item"><div className="muted">4xx</div><div className="v err">{s.buckets['4xx']}</div></div>
        <div className="item"><div className="muted">5xx</div><div className="v err">{s.buckets['5xx']}</div></div>
        <div className="item"><div className="muted">Users / Uploads</div><div className="v">{s.db.users} / {s.db.uploads}</div></div>
      </div>

      <h2 style={{marginTop:24}}>Top endpoints</h2>
      <div className="card">
        <table>
          <thead><tr><th>Endpoint</th><th>Hits</th></tr></thead>
          <tbody>
            {s.top_endpoints.map(([p, n]) => <tr key={p}><td>{p}</td><td>{n}</td></tr>)}
          </tbody>
        </table>
      </div>

      <h2>Recent events</h2>
      <div className="card" style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th>ts</th><th>method</th><th>path</th><th>status</th><th>UA</th></tr></thead>
          <tbody>
            {s.recent_events.map((e, i) => (
              <tr key={i}>
                <td>{new Date((e.ts||0)*1000).toLocaleTimeString()}</td>
                <td>{e.method}</td>
                <td>{e.path}{e.query?`?${e.query}`:''}</td>
                <td className={e.status>=400?'err':'ok'}>{e.status}</td>
                <td className="muted">{(e.user_agent||'').slice(0,40)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
