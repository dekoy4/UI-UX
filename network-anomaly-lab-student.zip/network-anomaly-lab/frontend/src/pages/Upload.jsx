import React, { useState } from 'react';
import { api } from '../api.js';

export default function Upload() {
  const [file, setFile] = useState(null);
  const [res, setRes] = useState(null);
  const [err, setErr] = useState(null);

  async function go(e) {
    e.preventDefault();
    setErr(null); setRes(null);
    if (!file) { setErr('no file'); return; }
    try { setRes(await api.upload(file)); }
    catch (e) { setErr(e.message); }
  }
  return (
    <>
      <h1>Upload</h1>
      <form onSubmit={go} className="card row">
        <input type="file" onChange={e=>setFile(e.target.files[0])} />
        <button type="submit">Upload</button>
      </form>
      {res && <p className="ok">Uploaded: {res.filename} ({res.size} bytes), id={res.id}</p>}
      {err && <p className="err">{err}</p>}
    </>
  );
}
