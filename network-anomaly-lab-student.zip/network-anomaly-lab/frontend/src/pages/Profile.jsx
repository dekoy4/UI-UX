import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Profile() {
  const [p, setP] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => { api.profile().then(setP).catch(e=>setErr(e.message)); }, []);
  return (
    <>
      <h1>Profile</h1>
      {err && <p className="err">{err}</p>}
      {p && (
        <div className="card">
          <p><strong>{p.username}</strong> ({p.role})</p>
          <p className="muted">Created: {p.created_at}</p>
        </div>
      )}
      {!p && !err && <p className="muted">Войдите, чтобы увидеть профиль.</p>}
    </>
  );
}
