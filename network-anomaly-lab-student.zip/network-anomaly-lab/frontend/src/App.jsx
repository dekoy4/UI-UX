import React from 'react';
import { Link, Route, Routes, Navigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Products from './pages/Products.jsx';
import Search from './pages/Search.jsx';
import Profile from './pages/Profile.jsx';
import Upload from './pages/Upload.jsx';
import Dashboard from './pages/Dashboard.jsx';

export default function App() {
  return (
    <>
      <nav>
        <strong>network-anomaly-lab</strong>
        <Link to="/login">Login</Link>
        <Link to="/products">Products</Link>
        <Link to="/search">Search</Link>
        <Link to="/profile">Profile</Link>
        <Link to="/upload">Upload</Link>
        <Link to="/dashboard">Dashboard</Link>
      </nav>
      <main>
        <Routes>
          <Route path="/" element={<Navigate to="/products" replace />} />
          <Route path="/login" element={<Login />} />
          <Route path="/products" element={<Products />} />
          <Route path="/search" element={<Search />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="*" element={<p>404</p>} />
        </Routes>
      </main>
    </>
  );
}
