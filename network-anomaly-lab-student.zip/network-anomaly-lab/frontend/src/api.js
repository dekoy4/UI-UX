// Тонкий API-клиент. Базовый URL пуст: Nginx проксирует /api на backend.

const tokenKey = 'lab_token';

export function setToken(t) {
  if (t) localStorage.setItem(tokenKey, t);
  else localStorage.removeItem(tokenKey);
}

export function getToken() {
  return localStorage.getItem(tokenKey);
}

async function request(path, { method = 'GET', body, headers, auth = false } = {}) {
  const opts = { method, headers: { ...(headers || {}) } };
  if (body !== undefined) {
    if (body instanceof FormData) {
      opts.body = body;
    } else {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
  }
  if (auth) {
    const t = getToken();
    if (t) opts.headers['Authorization'] = `Bearer ${t}`;
  }
  const res = await fetch(path, opts);
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = text; }
  if (!res.ok) {
    const err = new Error((data && data.detail) || `HTTP ${res.status}`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

export const api = {
  register: (username, password) => request('/api/auth/register', { method: 'POST', body: { username, password } }),
  login:    (username, password) => request('/api/auth/login',    { method: 'POST', body: { username, password } }),
  products: ()                   => request('/api/products'),
  product:  (id)                 => request(`/api/products/${id}`),
  search:   (q)                  => request(`/api/search?q=${encodeURIComponent(q)}`),
  profile:  ()                   => request('/api/profile', { auth: true }),
  upload:   (file)               => {
    const fd = new FormData(); fd.append('file', file);
    return request('/api/upload', { method: 'POST', body: fd });
  },
  files:    (name)               => request(`/api/files?name=${encodeURIComponent(name)}`),
  stats:    ()                   => request('/api/admin/stats'),
};
