"""SQLite-обёртка для учебного backend.

Используем стандартный sqlite3, чтобы не тащить ORM. База инициализируется
при старте FastAPI и хранится в каталоге, заданном переменной BACKEND_DB_PATH.
"""

from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

DB_PATH = os.environ.get("BACKEND_DB_PATH", "/data/app.db")


def _connect() -> sqlite3.Connection:
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


# Один общий connection — для учебного стенда этого достаточно.
_CONN: sqlite3.Connection | None = None


def get_conn() -> sqlite3.Connection:
    global _CONN
    if _CONN is None:
        _CONN = _connect()
    return _CONN


@contextmanager
def cursor() -> Iterator[sqlite3.Cursor]:
    conn = get_conn()
    cur = conn.cursor()
    try:
        yield cur
        conn.commit()
    finally:
        cur.close()


def init_db() -> None:
    """Создать таблицы и наполнить демо-данными (если пусто)."""
    with cursor() as cur:
        cur.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                price REAL NOT NULL,
                description TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS uploads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                size INTEGER NOT NULL,
                content_type TEXT,
                uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            """
        )

        # Демо-набор товаров (только если таблица пуста).
        cur.execute("SELECT COUNT(*) AS n FROM products")
        if cur.fetchone()["n"] == 0:
            demo = [
                ("Notebook Pro 14",    "laptops",     1499.00, "14\" ноутбук для разработки."),
                ("Notebook Air 13",    "laptops",      999.00, "Лёгкий 13\" ноутбук."),
                ("Mechanical Keyboard","accessories",  129.00, "Механическая клавиатура с подсветкой."),
                ("Wireless Mouse",     "accessories",   39.00, "Беспроводная мышь 2.4GHz."),
                ("4K Monitor 27",      "displays",     449.00, "27\" монитор 4K IPS."),
                ("USB-C Hub",          "accessories",   49.00, "USB-C хаб 7-в-1."),
                ("Webcam HD",          "accessories",   79.00, "1080p камера для встреч."),
                ("Headphones ANC",     "audio",        199.00, "Накладные наушники с шумоподавлением."),
                ("Router Wi-Fi 6",     "network",      149.00, "Двухдиапазонный роутер."),
                ("NAS 2-bay",          "storage",      299.00, "Сетевое хранилище на 2 диска."),
            ]
            cur.executemany(
                "INSERT INTO products(name, category, price, description) VALUES (?,?,?,?)",
                demo,
            )
