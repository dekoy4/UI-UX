"""Pydantic-модели запросов/ответов."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=4, max_length=128)


class LoginIn(BaseModel):
    username: str
    password: str


class TokenOut(BaseModel):
    token: str
    role: str


class ProductOut(BaseModel):
    id: int
    name: str
    category: str
    price: float
    description: str


class ProfileOut(BaseModel):
    username: str
    role: str
    created_at: Optional[str] = None


class UploadOut(BaseModel):
    id: int
    filename: str
    size: int


class StatsOut(BaseModel):
    users: int
    products: int
    uploads: int
