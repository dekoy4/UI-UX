"""FastAPI entrypoint.

- инициализирует SQLite и наполняет демо-товарами;
- включает CORS, JSONL-логирование запросов;
- поднимает все роутеры и эндпоинт /health;
- Swagger остаётся доступен по адресу /docs.
"""

from __future__ import annotations

import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .db import init_db
from .logging_middleware import RequestLoggingMiddleware
from .routers import admin, auth, files, products, profile, search, upload

CORS_ORIGIN = os.environ.get("BACKEND_CORS_ORIGIN", "*")

app = FastAPI(
    title="network-anomaly-lab API",
    version="1.0.0",
    docs_url="/docs",
    openapi_url="/openapi.json",
)

# CORS — для разработки разрешаем всё. В реальном проде так делать нельзя.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[CORS_ORIGIN] if CORS_ORIGIN != "*" else ["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Логирование всех запросов в JSONL.
app.add_middleware(RequestLoggingMiddleware)


@app.on_event("startup")
def _startup() -> None:
    init_db()


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


app.include_router(auth.router)
app.include_router(products.router)
app.include_router(search.router)
app.include_router(profile.router)
app.include_router(upload.router)
app.include_router(files.router)
app.include_router(admin.router)
