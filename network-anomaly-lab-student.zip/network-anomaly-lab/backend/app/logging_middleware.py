"""JSONL-логирование запросов.

Каждый запрос пишется одной строкой JSON в файл BACKEND_REQUEST_LOG.
Этот лог удобно скармливать студентам как «серверную» картину аномалий
(сопоставление с PCAP — отдельное задание).
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

LOG_PATH = os.environ.get("BACKEND_REQUEST_LOG", "/data/request_log.jsonl")


def _ensure_log_dir() -> None:
    Path(LOG_PATH).parent.mkdir(parents=True, exist_ok=True)


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        start = time.time()
        try:
            response = await call_next(request)
            status_code = response.status_code
        except Exception:
            status_code = 500
            raise
        finally:
            duration_ms = int((time.time() - start) * 1000)
            entry = {
                "ts": time.time(),
                "client": request.client.host if request.client else None,
                "method": request.method,
                "path": request.url.path,
                "query": request.url.query,
                "user_agent": request.headers.get("user-agent"),
                "status": status_code,
                "duration_ms": duration_ms,
                "content_length": request.headers.get("content-length"),
                "referer": request.headers.get("referer"),
            }
            try:
                _ensure_log_dir()
                with open(LOG_PATH, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            except OSError:
                # лог не должен ронять запрос
                pass
        return response
