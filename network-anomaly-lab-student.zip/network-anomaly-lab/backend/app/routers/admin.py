"""/api/admin/stats

Открыт публично (это учебный стенд). Используется dashboard'ом
фронтенда. Не отдаёт список аномалий — только агрегаты, по которым
студенты должны самостоятельно догадаться, что что-то не так.
"""

from __future__ import annotations

import json
import os
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

from fastapi import APIRouter

from ..db import cursor
from ..logging_middleware import LOG_PATH

router = APIRouter(prefix="/api/admin", tags=["admin"])


def _read_log_tail(path: str, max_entries: int = 2000) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    # Простое чтение последних N строк (для учебного объёма норм).
    try:
        with p.open("r", encoding="utf-8") as f:
            lines = f.readlines()[-max_entries:]
    except OSError:
        return []
    out: List[Dict[str, Any]] = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


@router.get("/stats")
def stats() -> Dict[str, Any]:
    entries = _read_log_tail(LOG_PATH)
    statuses = Counter()
    bucket_2xx = bucket_4xx = bucket_5xx = 0
    endpoints = Counter()
    for e in entries:
        code = e.get("status")
        if isinstance(code, int):
            statuses[code] += 1
            if 200 <= code < 300:
                bucket_2xx += 1
            elif 400 <= code < 500:
                bucket_4xx += 1
            elif 500 <= code < 600:
                bucket_5xx += 1
        path = e.get("path")
        if isinstance(path, str):
            endpoints[path] += 1

    with cursor() as cur:
        cur.execute("SELECT COUNT(*) AS n FROM users")
        users = cur.fetchone()["n"]
        cur.execute("SELECT COUNT(*) AS n FROM products")
        products = cur.fetchone()["n"]
        cur.execute("SELECT COUNT(*) AS n FROM uploads")
        uploads = cur.fetchone()["n"]

    return {
        "total_requests": len(entries),
        "by_status": dict(statuses),
        "buckets": {"2xx": bucket_2xx, "4xx": bucket_4xx, "5xx": bucket_5xx},
        "top_endpoints": endpoints.most_common(10),
        "recent_events": entries[-20:],
        "db": {"users": users, "products": products, "uploads": uploads},
    }
