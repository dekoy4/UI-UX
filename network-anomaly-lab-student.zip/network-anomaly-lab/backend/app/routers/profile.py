"""/api/profile"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from ..auth import require_user
from ..db import cursor
from ..models import ProfileOut

router = APIRouter(prefix="/api/profile", tags=["profile"])


@router.get("", response_model=ProfileOut)
def get_profile(user=Depends(require_user)) -> ProfileOut:
    with cursor() as cur:
        cur.execute(
            "SELECT username, role, created_at FROM users WHERE username = ?",
            (user["sub"],),
        )
        row = cur.fetchone()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "user not found")
    return ProfileOut(**dict(row))
