"""/api/auth/*"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status

from ..auth import hash_password, issue_token, verify_password
from ..db import cursor
from ..models import LoginIn, RegisterIn, TokenOut

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/register", response_model=TokenOut)
def register(body: RegisterIn) -> TokenOut:
    with cursor() as cur:
        cur.execute("SELECT id FROM users WHERE username = ?", (body.username,))
        if cur.fetchone() is not None:
            # Учебно: общий 400, чтобы не было user enumeration.
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "registration failed")
        cur.execute(
            "INSERT INTO users(username, password_hash, role) VALUES (?,?,?)",
            (body.username, hash_password(body.password), "user"),
        )
    return TokenOut(token=issue_token(body.username, "user"), role="user")


@router.post("/login", response_model=TokenOut)
def login(body: LoginIn) -> TokenOut:
    with cursor() as cur:
        cur.execute(
            "SELECT username, password_hash, role FROM users WHERE username = ?",
            (body.username,),
        )
        row = cur.fetchone()
    if row is None or not verify_password(body.password, row["password_hash"]):
        # Один общий код, чтобы brute force нельзя было разделить на «нет юзера» / «не тот пароль».
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid credentials")
    return TokenOut(token=issue_token(row["username"], row["role"]), role=row["role"])
