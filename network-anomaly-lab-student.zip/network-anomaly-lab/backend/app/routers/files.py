"""/api/files

Эндпоинт намеренно «нестрогий»: принимает параметр name и пытается
найти файл в whitelist'е. Path traversal реально не работает (мы
сравниваем имя по списку), но любые попытки traversal логируются
и возвращают 403, чтобы попасть в JSONL и PCAP.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, status
from fastapi.responses import PlainTextResponse

router = APIRouter(prefix="/api/files", tags=["files"])

# Жёстко зашитый список «публичных» файлов и их содержимое.
_PUBLIC = {
    "readme.txt": "Network anomaly lab — public file.\n",
    "policy.txt": "Acceptable use policy: лабораторный стенд.\n",
    "changelog.txt": "v1.0.0 — initial release.\n",
}


def _looks_like_traversal(name: str) -> bool:
    bad_tokens = ("..", "/", "\\", "%2e", "%2f", "%5c", "\x00")
    lowered = name.lower()
    return any(tok in lowered for tok in bad_tokens)


@router.get("")
def get_file(name: str = Query(..., max_length=128)) -> PlainTextResponse:
    if _looks_like_traversal(name):
        # 403 чтобы выделялся в логах.
        raise HTTPException(status.HTTP_403_FORBIDDEN, "forbidden path")
    if name not in _PUBLIC:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "file not found")
    return PlainTextResponse(_PUBLIC[name])
