"""/api/search

Учебная реализация: запросы выполняются параметризованно — SQL-инъекция
не сработает. Однако подозрительные payload (UNION, кавычки, комментарии)
логируются и возвращают 400, чтобы студенты могли увидеть их на сервере
и сопоставить с сетевым следом.
"""

from __future__ import annotations

import re
from typing import List

from fastapi import APIRouter, HTTPException, Query, status

from ..db import cursor
from ..models import ProductOut

router = APIRouter(prefix="/api/search", tags=["search"])

# Простейшие индикаторы SQLi/traversal — учебные, не для прод.
_SUSPICIOUS = re.compile(
    r"('|--|;|\bOR\b\s+1=1|\bUNION\b|\bSELECT\b|/etc/passwd|\.\./|\.\.\\)",
    re.IGNORECASE,
)


@router.get("", response_model=List[ProductOut])
def search(q: str = Query(default="", max_length=200)) -> List[ProductOut]:
    if _SUSPICIOUS.search(q):
        # Возвращаем 400 — это позволит студентам увидеть всплеск 4xx.
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "suspicious query")
    pattern = f"%{q}%"
    with cursor() as cur:
        cur.execute(
            """
            SELECT id, name, category, price, description
              FROM products
             WHERE name LIKE ? OR description LIKE ? OR category LIKE ?
             ORDER BY id
             LIMIT 50
            """,
            (pattern, pattern, pattern),
        )
        rows = cur.fetchall()
    return [ProductOut(**dict(r)) for r in rows]
