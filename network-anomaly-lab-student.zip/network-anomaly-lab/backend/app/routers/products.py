"""/api/products"""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, HTTPException, status

from ..db import cursor
from ..models import ProductOut

router = APIRouter(prefix="/api/products", tags=["products"])


@router.get("", response_model=List[ProductOut])
def list_products() -> List[ProductOut]:
    with cursor() as cur:
        cur.execute("SELECT id, name, category, price, description FROM products ORDER BY id")
        rows = cur.fetchall()
    return [ProductOut(**dict(r)) for r in rows]


@router.get("/{product_id}", response_model=ProductOut)
def get_product(product_id: int) -> ProductOut:
    with cursor() as cur:
        cur.execute(
            "SELECT id, name, category, price, description FROM products WHERE id = ?",
            (product_id,),
        )
        row = cur.fetchone()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "product not found")
    return ProductOut(**dict(row))
