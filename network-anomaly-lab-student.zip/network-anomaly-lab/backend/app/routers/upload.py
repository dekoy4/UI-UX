"""/api/upload

Файлы НЕ сохраняются на диск — мы лишь меряем размер и пишем запись в БД.
Это намеренно: лаба моделирует exfiltration по объёму POST, а не настоящий
файловый сервис.
"""

from __future__ import annotations

from fastapi import APIRouter, File, HTTPException, UploadFile, status

from ..db import cursor
from ..models import UploadOut

router = APIRouter(prefix="/api/upload", tags=["upload"])

# Ограничение на размер тела (10 МБ) — больше отвергаем 413.
MAX_UPLOAD_BYTES = 10 * 1024 * 1024


@router.post("", response_model=UploadOut)
async def upload(file: UploadFile = File(...)) -> UploadOut:
    # Считаем размер потоково, не держим весь файл в памяти.
    total = 0
    while True:
        chunk = await file.read(64 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > MAX_UPLOAD_BYTES:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "file too large")

    with cursor() as cur:
        cur.execute(
            "INSERT INTO uploads(filename, size, content_type) VALUES (?,?,?)",
            (file.filename or "unnamed", total, file.content_type),
        )
        upload_id = cur.lastrowid
    return UploadOut(id=upload_id, filename=file.filename or "unnamed", size=total)
