"""Лёгкая auth-обёртка для учебного backend.

Хэшируем пароли bcrypt'ом и выдаём короткоживущие JWT. Любая ошибка
аутентификации возвращает 401 без подсказок (никакого user enumeration).
"""

from __future__ import annotations

import os
import time
from typing import Optional

import jwt
from fastapi import Header, HTTPException, status
from passlib.context import CryptContext

JWT_SECRET = os.environ.get("BACKEND_JWT_SECRET", "lab-secret-do-not-use-in-prod")
JWT_ALG = "HS256"
JWT_TTL = 60 * 60  # 1 час

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return _pwd.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _pwd.verify(password, password_hash)
    except Exception:
        return False


def issue_token(username: str, role: str = "user") -> str:
    now = int(time.time())
    payload = {
        "sub": username,
        "role": role,
        "iat": now,
        "exp": now + JWT_TTL,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except Exception:
        return None


def require_user(authorization: Optional[str] = Header(default=None)) -> dict:
    """FastAPI dependency: достаёт пользователя из Bearer-токена."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "missing bearer token")
    token = authorization.split(" ", 1)[1].strip()
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid token")
    return payload
