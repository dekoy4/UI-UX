"""Минимальные smoke-тесты backend.

Запускаются командой `make test`. БД и лог-файл подменяются на временные,
чтобы тесты не трогали учебные данные.
"""

from __future__ import annotations

import os
import tempfile

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="session")
def client():
    tmp = tempfile.mkdtemp(prefix="lab_test_")
    os.environ["BACKEND_DB_PATH"] = os.path.join(tmp, "app.db")
    os.environ["BACKEND_REQUEST_LOG"] = os.path.join(tmp, "request_log.jsonl")
    # Импорт после переустановки переменных — чтобы db.DB_PATH прочитался свежим.
    from app import db as db_mod
    db_mod.DB_PATH = os.environ["BACKEND_DB_PATH"]
    db_mod._CONN = None  # type: ignore[attr-defined]

    from app.main import app  # noqa: WPS433
    with TestClient(app) as c:
        yield c


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_register_login_profile(client):
    # 1) регистрация
    r = client.post("/api/auth/register", json={"username": "alice", "password": "secret"})
    assert r.status_code == 200, r.text
    token = r.json()["token"]
    assert token

    # 2) логин
    r = client.post("/api/auth/login", json={"username": "alice", "password": "secret"})
    assert r.status_code == 200
    token = r.json()["token"]

    # 3) профиль с токеном
    r = client.get("/api/profile", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["username"] == "alice"

    # 4) профиль без токена
    r = client.get("/api/profile")
    assert r.status_code == 401


def test_login_invalid(client):
    r = client.post("/api/auth/login", json={"username": "nobody", "password": "x"})
    assert r.status_code == 401
    r = client.post("/api/auth/login", json={"username": "alice", "password": "wrong"})
    assert r.status_code == 401


def test_products(client):
    r = client.get("/api/products")
    assert r.status_code == 200
    body = r.json()
    assert len(body) >= 5
    pid = body[0]["id"]
    r = client.get(f"/api/products/{pid}")
    assert r.status_code == 200
    assert r.json()["id"] == pid
    r = client.get("/api/products/99999")
    assert r.status_code == 404


def test_search_normal_and_suspicious(client):
    r = client.get("/api/search", params={"q": "Notebook"})
    assert r.status_code == 200
    # SQLi-payload должен быть отвергнут.
    r = client.get("/api/search", params={"q": "' OR 1=1 --"})
    assert r.status_code == 400


def test_files_traversal(client):
    r = client.get("/api/files", params={"name": "readme.txt"})
    assert r.status_code == 200
    r = client.get("/api/files", params={"name": "../../etc/passwd"})
    assert r.status_code == 403
    r = client.get("/api/files", params={"name": "nosuch.txt"})
    assert r.status_code == 404


def test_upload_small(client):
    files = {"file": ("hello.txt", b"hello world", "text/plain")}
    r = client.post("/api/upload", files=files)
    assert r.status_code == 200
    body = r.json()
    assert body["size"] == len(b"hello world")


def test_admin_stats(client):
    r = client.get("/api/admin/stats")
    assert r.status_code == 200
    body = r.json()
    assert "buckets" in body and "top_endpoints" in body
