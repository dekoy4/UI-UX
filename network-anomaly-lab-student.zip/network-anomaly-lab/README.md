# network-anomaly-lab

Учебный Docker-стенд по дисциплине **«Сети и протоколы»**. Поднимает
реалистичную мини-инфраструктуру (frontend + backend + reverse proxy),
позволяет сгенерировать нормальный и аномальный HTTP-трафик, снять PCAP,
прогнать его через TShark/Zeek/Suricata и **самостоятельно** найти
сетевые аномалии.

> Стенд предназначен **только для локального использования** в учебной
> среде. Не публикуйте его порты на внешние интерфейсы и не запускайте
> traffic-generator против чужих сервисов — он откажется.

---

## 1. Что внутри

| Сервис             | Назначение                                     |
| ------------------ | ---------------------------------------------- |
| `backend`          | FastAPI + SQLite, REST API + Swagger           |
| `nginx`            | reverse proxy + статика SPA + access-логи      |
| `traffic-generator`| Python-скрипт нормального и аномального трафика|
| `sensor`           | tcpdump + tshark + Python детектор             |
| `suricata` (опц.)  | IDS с учебными правилами                       |
| `evebox` (опц.)    | веб-UI для `eve.json`                          |

Дерево директорий:

```
network-anomaly-lab/
  docker-compose.yml
  Makefile
  .env.example
  README.md
  LAB_TASK.md
  backend/             # FastAPI
  frontend/            # React + Vite
  nginx/               # reverse proxy + multi-stage build фронта
  traffic-generator/   # генератор нормального/аномального трафика
  sensor/              # capture/extract/detector
  scripts/ids/         # Suricata: yaml + local.rules
  reports/             # PCAP, CSV, JSON-отчёты
```

---

## 2. Требования

* Linux/macOS с Docker Engine ≥ 24 и `docker compose` plugin.
* Свободные порты на `127.0.0.1`: **8080** (стенд) и **5636** (EveBox, опц.).
* 2–3 GB свободного места под образы.

Опционально на хосте:
* `tshark` — если хотите анализировать PCAP вне контейнера sensor.
* Wireshark — для интерактивного разбора.

---

## 3. Быстрый старт

```bash
cp .env.example .env            # один раз
make up                         # docker compose up -d --build
make ps                         # проверить, что всё healthy
open http://127.0.0.1:8080      # frontend + dashboard
open http://127.0.0.1:8080/docs # Swagger API
```

Стенд считается готовым, когда у `backend` и `nginx` статус `healthy`.

---

## 4. Запуск трафика и анализ

```bash
# 1) фоновый захват PCAP (длительность 90 секунд)
make capture DURATION=90 &

# 2) одновременно гоним микс нормального и аномального трафика
make mixed DURATION=60

# 3) ждём окончания захвата (см. фоновый job)
wait

# 4) извлекаем HTTP-поля в CSV
make extract

# 5) запускаем студенческий детектор
make detect

# 6) преподаватель: эталонный детектор и ground truth
make detect-solution
cat reports/ground_truth.json
```

Альтернативные сценарии:

```bash
make normal     DURATION=60   # только нормальный трафик
make anomalies  DURATION=60   # только аномальный трафик
```

Опциональный IDS-профиль:

```bash
make ids-up                      # поднять Suricata + EveBox
open http://127.0.0.1:5636       # UI EveBox
# eve.json лежит в volume suricata_logs
make ids-down
```

---

## 5. Полезные команды

| Команда                | Назначение                              |
| ---------------------- | --------------------------------------- |
| `make help`            | список всех целей                       |
| `make logs`            | хвост логов всех сервисов               |
| `make ps`              | статус контейнеров                      |
| `make test`            | прогнать тесты backend                  |
| `make backend-shell`   | shell в backend                         |
| `make sensor-shell`    | shell в sensor                          |
| `make traffic-shell`   | shell в traffic-generator               |
| `make down`            | остановить контейнеры (volume сохранён) |
| `make nuke`            | полная очистка контейнеров и volume     |

---

## 6. Troubleshooting

### tcpdump: «Operation not permitted»
Контейнеру `sensor` уже выдан `cap_add: NET_ADMIN/NET_RAW`. Если ошибка
сохраняется, на хосте включён жёсткий `seccomp`/`apparmor`-профиль —
запустите Docker с дефолтным профилем безопасности.

### `tshark: command not found` на хосте
Команды `make extract`, `make detect` выполняются **внутри контейнера
sensor**, где tshark предустановлен. На хосте tshark не нужен.

### Контейнеры не видят друг друга
Сервисы пользуются сетью `${LAB_NETWORK_NAME}` (по умолчанию
`anomaly_net`). Проверьте: `docker network inspect anomaly_net`. Если
адресный конфликт с подсетью хоста — переопределите `LAB_SUBNET` в `.env`.

### PCAP пустой
1. Убедитесь, что трафик действительно был: `make ps` показывает healthy,
   а `make mixed DURATION=10` отработал без ошибок.
2. Захват слушает интерфейс `eth0` внутри контейнера. Если ваш Docker
   создаёт интерфейс с другим именем (редко), задайте `SENSOR_IFACE` в `.env`.
3. Запустите capture **до** трафика: `make capture DURATION=60 &` и затем
   `make mixed DURATION=30`.

### Frontend не открывается
`make logs` → смотрим `lab_nginx`. Если контейнер пишет про permission на
volume `frontend_dist` — пересоберите образы: `make build`.

### Suricata `permission denied` на eve.json
Volume `suricata_logs` создаётся при первом запуске. После `make nuke`
переподнимите профиль ids: `make ids-up`.

---

## 7. Остановка и очистка

```bash
make down       # контейнеры остановлены, volume сохранены
make nuke       # удалить контейнеры, volume и локальные образы стенда
```

---

## 8. Безопасность

* Все порты пробрасываются на `127.0.0.1`, никогда на `0.0.0.0`.
* Traffic generator **отказывается** работать против любого хоста, который
  не является `nginx`, `localhost`, `127.0.0.1` или адресом из частных
  Docker-сетей.
* «Атаки» в генераторе моделируют **сетевой признак** аномалии (логи,
  pcap, eve.json) — реальной эксплуатации нет.
* `flood` ограничен ≤ 15 RPS и ≤ 20 секунд.
* Подозрительные payload backend честно отвергает (400/403) и пишет в
  JSONL-лог.

---

## 9. Деплой на чистый Ubuntu-сервер

См. `scripts/deploy/install_ubuntu.sh`. Кратко:

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release; echo $VERSION_CODENAME) stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo usermod -aG docker "$USER" && newgrp docker

# заливаем архив и запускаем
tar -xzf network-anomaly-lab.tar.gz
cd network-anomaly-lab
cp .env.example .env
make up
```
